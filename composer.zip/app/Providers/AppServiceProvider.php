<?php

namespace App\Providers;

use App\Support\ApiPath;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        $directory = ApiPath::directory();
        if ($directory !== '' && blank(config('app.asset_url'))) {
            config(['app.asset_url' => '/'.$directory]);
        }
    }
}
