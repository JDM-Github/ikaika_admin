<?php

namespace App\Support;

use Illuminate\Http\Request;

class ApiPath
{
    /**
     * Directory in front of /api, with no slashes. Empty locally.
     */
    public static function directory(): string
    {
        return trim((string) config('products.path_prefix', ''), '/');
    }

    /**
     * Laravel route prefix: "api" or "staging/central-api/api".
     */
    public static function routePrefix(): string
    {
        $directory = self::directory();

        return $directory === '' ? 'api' : $directory.'/api';
    }

    /**
     * Leading-slash URL root: "/api" or "/staging/central-api/api".
     */
    public static function prefix(): string
    {
        return '/'.self::routePrefix();
    }

    public static function join(string ...$segments): string
    {
        $parts = [];
        foreach ($segments as $segment) {
            $trimmed = trim($segment, '/');
            if ($trimmed !== '') {
                $parts[] = $trimmed;
            }
        }

        return self::prefix().($parts === [] ? '' : '/'.implode('/', $parts));
    }

    public static function convention(): string
    {
        return self::prefix().'/{channel}/{product}/{resource}';
    }

    /**
     * Path the browser should fetch. A leading /api/... is origin-absolute and hits WordPress
     * at the domain root; this prepends the subdirectory the playground is actually served from.
     */
    public static function publicPath(string ...$segments): string
    {
        $routePath = $segments === [] ? self::prefix() : self::join(...$segments);
        $appPath = rtrim((string) parse_url(url('/'), PHP_URL_PATH), '/');

        if ($appPath === '' || str_starts_with($routePath, $appPath.'/') || $routePath === $appPath) {
            return $routePath;
        }

        return $appPath.$routePath;
    }

    public static function isApiRequest(Request $request): bool
    {
        $prefix = self::routePrefix();

        return $request->is($prefix) || $request->is($prefix.'/*');
    }
}
